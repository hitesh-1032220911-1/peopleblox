module.exports = {

"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/src/pages/api/industries.ts [api] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>handler
});
async function handler(req, res// The response we'll send back
) {
    // Only allow GET requests (no POST, PUT, DELETE)
    if (req.method !== 'GET') {
        return res.status(405).json({
            message: 'Method not allowed'
        });
    }
    try {
        // Step 1: Fetch data from the external Peopleblox API
        const response = await fetch('https://peopleblox.io/api/get-competency-file?fileName=industry.json');
        // Step 2: Check if the request was successful
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        // Step 3: Convert the response to JSON
        const data = await response.json();
        // Step 4: Fix the image URLs (convert relative paths to absolute URLs)
        const processedData = data.map((industry)=>({
                ...industry,
                ImageUrl: industry.ImageUrl ? `https://peopleblox.io${industry.ImageUrl}` // Add the base URL
                 : industry.ImageUrl // Keep as is if no image
            }));
        // Step 5: Send the processed data back to the frontend
        res.status(200).json(processedData);
    } catch (error) {
        // If anything goes wrong, log the error and send an error response
        console.error('Error fetching industries:', error);
        res.status(500).json({
            message: 'Failed to fetch industries'
        });
    }
}
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__e69380e5._.js.map