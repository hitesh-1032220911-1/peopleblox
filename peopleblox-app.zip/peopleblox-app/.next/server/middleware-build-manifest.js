globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_c2daf96a._.js",
      "static/chunks/node_modules_next_router_47d9bb1c.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_@mui_system_esm_051b1976._.js",
      "static/chunks/node_modules_@mui_material_esm_92810a97._.js",
      "static/chunks/node_modules_@reduxjs_toolkit_dist_8ef84d39._.js",
      "static/chunks/node_modules_12e9b64e._.js",
      "static/chunks/[root-of-the-server]__4b887e24._.js",
      "static/chunks/src_pages_index_5771e187._.js",
      "static/chunks/src_pages_index_0b38acd4._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_c2daf96a._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_@mui_system_esm_b96ef3d9._.js",
      "static/chunks/node_modules_@mui_material_esm_73fd016e._.js",
      "static/chunks/node_modules_@reduxjs_toolkit_dist_8ef84d39._.js",
      "static/chunks/node_modules_0b507aec._.js",
      "static/chunks/[root-of-the-server]__6f479e77._.js",
      "static/chunks/src_pages__app_5771e187._.js",
      "static/chunks/src_pages__app_0d464d8b._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_3cbd5cc2._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_7c4b9b2a._.js",
      "static/chunks/node_modules_next_error_8c8bf619.js",
      "static/chunks/[next]_entry_page-loader_ts_8ccf5f86._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_f2979c3a._.js",
      "static/chunks/[root-of-the-server]__c194513e._.js",
      "static/chunks/src_pages__error_5771e187._.js",
      "static/chunks/src_pages__error_21a636e5._.js"
    ],
    "/industry/[id]": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
      "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
      "static/chunks/node_modules_next_dist_client_becf32a6._.js",
      "static/chunks/node_modules_next_dist_c2daf96a._.js",
      "static/chunks/node_modules_next_router_47d9bb1c.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_@mui_system_esm_285d012c._.js",
      "static/chunks/node_modules_@mui_material_esm_dc571773._.js",
      "static/chunks/node_modules_@reduxjs_toolkit_dist_8ef84d39._.js",
      "static/chunks/node_modules_16bd23cd._.js",
      "static/chunks/[root-of-the-server]__51372b03._.js",
      "static/chunks/src_pages_industry_[id]_tsx_5771e187._.js",
      "static/chunks/src_pages_industry_[id]_tsx_cb25afe9._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];