(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
  "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
  "static/chunks/node_modules_next_dist_client_becf32a6._.js",
  "static/chunks/node_modules_next_dist_c2daf96a._.js",
  "static/chunks/node_modules_next_router_47d9bb1c.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_@mui_system_esm_285d012c._.js",
  "static/chunks/node_modules_@mui_material_esm_dc571773._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_dist_8ef84d39._.js",
  "static/chunks/node_modules_16bd23cd._.js",
  "static/chunks/[root-of-the-server]__51372b03._.js"
],
    source: "entry"
});
