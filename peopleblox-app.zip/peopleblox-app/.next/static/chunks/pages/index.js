__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_82a36480.js",
  "static/chunks/node_modules_next_dist_compiled_ca41998d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_492fcef6._.js",
  "static/chunks/node_modules_next_dist_client_becf32a6._.js",
  "static/chunks/node_modules_next_dist_c2daf96a._.js",
  "static/chunks/node_modules_next_router_47d9bb1c.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_@mui_system_esm_051b1976._.js",
  "static/chunks/node_modules_@mui_material_esm_92810a97._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_dist_8ef84d39._.js",
  "static/chunks/node_modules_12e9b64e._.js",
  "static/chunks/[root-of-the-server]__4b887e24._.js",
  "static/chunks/src_pages_index_5771e187._.js",
  "static/chunks/src_pages_index_0b38acd4._.js"
])
