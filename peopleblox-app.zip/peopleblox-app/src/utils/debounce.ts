// This function helps prevent too many API calls when user types quickly
// It waits for the user to stop typing for a certain time before doing something
export function debounce<T extends (...args: any[]) => any>(
  func: T,        // The function to call (like search)
  delay: number   // How long to wait (like 300ms)
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout;  // Stores the timer
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);  // Cancel the previous timer
    timeoutId = setTimeout(() => func(...args), delay);  // Start a new timer
  };
}

// Example: If user types "banking" quickly:
// 1. User types "b" → timer starts (300ms)
// 2. User types "a" → previous timer cancelled, new timer starts (300ms)
// 3. User types "n" → previous timer cancelled, new timer starts (300ms)
// 4. User types "k" → previous timer cancelled, new timer starts (300ms)
// 5. User types "i" → previous timer cancelled, new timer starts (300ms)
// 6. User types "n" → previous timer cancelled, new timer starts (300ms)
// 7. User types "g" → previous timer cancelled, new timer starts (300ms)
// 8. User stops typing → after 300ms, search function runs with "banking" 