import React from 'react';
import {
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Grid,
} from '@mui/material';

// This component shows the filter and sort controls
interface FiltersProps {
  sortBy: string;                    // Current sort option (A-Z, Z-A, etc.)
  onSortChange: (value: string) => void;  // Function to call when sort changes
  filterText: string;                // Current filter text
  onFilterChange: (value: string) => void;  // Function to call when filter changes
}

export default function Filters({
  sortBy,
  onSortChange,
  filterText,
  onFilterChange,
}: FiltersProps) {
  return (
    <Box sx={{ mb: 3, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
      {/* Light gray background box for the filters */}
      
      <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, gap: 2, alignItems: 'center' }}>
        {/* Responsive layout: column on mobile, row on desktop */}
        
        {/* Filter text box */}
        <Box sx={{ flex: 1, minWidth: { sm: '200px' } }}>
          <TextField
            label="Filter by name or description"  // Label above the text box
            value={filterText}  // What user has typed
            onChange={(e) => onFilterChange(e.target.value)}  // Update when user types
            fullWidth           // Take full width
            size="small"        // Smaller size
          />
        </Box>
        
        {/* Sort dropdown */}
        <Box sx={{ flex: 1, minWidth: { sm: '200px' } }}>
          <FormControl fullWidth size="small">
            <InputLabel>Sort by</InputLabel>  {/* Label for the dropdown */}
            <Select
              value={sortBy}  // Current selected option
              label="Sort by"
              onChange={(e) => onSortChange(e.target.value)}  // Update when user selects
            >
              {/* Dropdown options */}
              <MenuItem value="name-asc">Name (A-Z)</MenuItem>        {/* Sort by name A to Z */}
              <MenuItem value="name-desc">Name (Z-A)</MenuItem>       {/* Sort by name Z to A */}
              <MenuItem value="description-asc">Description (A-Z)</MenuItem>  {/* Sort by description A to Z */}
              <MenuItem value="description-desc">Description (Z-A)</MenuItem> {/* Sort by description Z to A */}
            </Select>
          </FormControl>
        </Box>
      </Box>
    </Box>
  );
} 