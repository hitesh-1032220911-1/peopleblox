import React from 'react';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Chip,
  Box,
  CardActionArea,
} from '@mui/material';
import { Industry } from '../store/api/industriesApi';
import { useRouter } from 'next/router';

// This component shows one industry as a card
interface IndustryCardProps {
  industry: Industry;  // The industry data to display
}

export default function IndustryCard({ industry }: IndustryCardProps) {
  const router = useRouter();  // Used to navigate to different pages

  // When user clicks the card, go to the detail page for this industry
  const handleClick = () => {
    router.push(`/industry/${encodeURIComponent(industry.Industry)}`);
  };

  return (
    <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* CardActionArea makes the whole card clickable */}
      <CardActionArea onClick={handleClick} sx={{ flexGrow: 1 }}>
        
        {/* Industry image at the top */}
        <CardMedia
          component="img"
          height="140"
          image={industry.ImageUrl || '/placeholder.jpg'}  // Show placeholder if no image
          alt={industry.Industry}  // Alt text for accessibility
          sx={{ objectFit: 'cover' }}  // Make image cover the whole area
        />
        
        {/* Card content below the image */}
        <CardContent sx={{ flexGrow: 1 }}>
          {/* Industry name */}
          <Typography gutterBottom variant="h6" component="div">
            {industry.Industry}
          </Typography>
          
          {/* Industry description */}
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {industry.Description}
          </Typography>
          
          {/* Show example companies if they exist */}
          {industry["Example Companies"] && (
            <Box sx={{ mb: 1 }}>
              <Typography variant="caption" color="text.secondary">
                Example Companies:
              </Typography>
              <Box sx={{ mt: 0.5 }}>
                {/* Split companies by comma and show first 3 */}
                {industry["Example Companies"].split(', ').slice(0, 3).map((company: string, index: number) => (
                  <Chip
                    key={index}
                    label={company}
                    size="small"
                    sx={{ mr: 0.5, mb: 0.5 }}
                  />
                ))}
              </Box>
            </Box>
          )}

          {/* Show example roles if they exist */}
          {industry["Example Roles"] && (
            <Box>
              <Typography variant="caption" color="text.secondary">
                Example Roles:
              </Typography>
              <Box sx={{ mt: 0.5 }}>
                {/* Split roles by comma and show first 2 */}
                {industry["Example Roles"].split(', ').slice(0, 2).map((role: string, index: number) => (
                  <Chip
                    key={index}
                    label={role}
                    size="small"
                    variant="outlined"  // Different style for roles
                    sx={{ mr: 0.5, mb: 0.5 }}
                  />
                ))}
              </Box>
            </Box>
          )}
        </CardContent>
      </CardActionArea>
    </Card>
  );
} 