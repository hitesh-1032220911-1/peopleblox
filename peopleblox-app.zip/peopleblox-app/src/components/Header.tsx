import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  TextField,
  InputAdornment,
  Box,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

// This component shows the header bar with app title and search box
interface HeaderProps {
  onSearch: (searchTerm: string) => void;  // Function to call when user searches
}

export default function Header({ onSearch }: HeaderProps) {
  // This stores what the user types in the search box
  const [searchTerm, setSearchTerm] = useState('');

  // This effect runs whenever searchTerm changes
  // It waits 300ms after user stops typing, then calls onSearch
  // This is called "debouncing" - prevents too many API calls
  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(searchTerm);  // Tell parent component about the search
    }, 300);  // Wait 300 milliseconds

    // Clean up the timer if user types again before 300ms
    return () => clearTimeout(timer);
  }, [searchTerm, onSearch]);

  return (
    <AppBar position="static">
      {/* AppBar is Material UI's header bar component */}
      <Toolbar>
        {/* Toolbar contains the header content */}
        
        {/* App title on the left */}
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Peopleblox Industries
        </Typography>
        
        {/* Search box on the right */}
        <Box sx={{ minWidth: 300 }}>
          <TextField
            placeholder="Search industries, roles, competencies..."  // Hint text
            value={searchTerm}  // What user has typed
            onChange={(e) => setSearchTerm(e.target.value)}  // Update when user types
            variant="outlined"  // Style of the text box
            size="small"        // Smaller size
            fullWidth           // Take full width of container
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />  {/* Search icon inside the text box */}
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                backgroundColor: 'white',  // White background
                '& fieldset': {
                  borderColor: 'transparent',  // No border
                },
              },
            }}
          />
        </Box>
      </Toolbar>
    </AppBar>
  );
} 