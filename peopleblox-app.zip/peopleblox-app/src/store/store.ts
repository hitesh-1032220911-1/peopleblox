import { configureStore } from '@reduxjs/toolkit';
import { industriesApi } from './api/industriesApi';

// This creates our main Redux store - it's like a central data warehouse
// All our app data and API calls go through this store
export const store = configureStore({
  reducer: {
    // This adds our industries API to the store
    // Now we can fetch industry data from anywhere in our app
    [industriesApi.reducerPath]: industriesApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    // This adds the API middleware so we can make API calls
    getDefaultMiddleware().concat(industriesApi.middleware),
});

// These are TypeScript types for the store
// They help us write better code with autocomplete
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch; 