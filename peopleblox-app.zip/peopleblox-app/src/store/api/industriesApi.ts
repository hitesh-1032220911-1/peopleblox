import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

// This defines what data structure we expect from the API
// Each industry has these fields (some are optional with ?)
export interface Industry {
  Industry: string;                    // Name of the industry (e.g., "Banking", "IT")
  Description: string;                 // What this industry is about
  "Common Observable Behaviors"?: string; // Skills people in this industry need (optional)
  "Example Companies"?: string;        // Companies in this industry (optional)
  "Example Roles"?: string;            // Job roles in this industry (optional)
  ImageUrl: string;                    // URL for the industry image
}

// This creates our API connection using Redux Toolkit Query
// It handles fetching data, caching, and loading states automatically
export const industriesApi = createApi({
  reducerPath: 'industriesApi',        // Name for this API in Redux store
  baseQuery: fetchBaseQuery({ 
    baseUrl: '/api',                   // All API calls will start with /api
  }),
  endpoints: (builder) => ({
    // This endpoint gets ALL industries (no parameters needed)
    getIndustries: builder.query<Industry[], void>({
      query: () => '/industries',      // Calls our local API route
    }),
    // This endpoint gets industries for detail page (we get all and filter client-side)
    getIndustryById: builder.query<Industry[], string>({
      query: (id) => '/industries',    // Same endpoint, we'll filter by ID later
    }),
  }),
});

// These are the hooks we'll use in our components to fetch data
// useGetIndustriesQuery - gets all industries for the main page
// useGetIndustryByIdQuery - gets industries for detail page
export const { useGetIndustriesQuery, useGetIndustryByIdQuery } = industriesApi; 