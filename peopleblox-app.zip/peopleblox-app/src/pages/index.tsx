import React, { useState, useMemo } from 'react';
import {
  Container,
  Grid,
  Typography,
  Box,
  CircularProgress,
  Alert,
  Skeleton,
} from '@mui/material';
import { useGetIndustriesQuery } from '../store/api/industriesApi';
import Header from '../components/Header';
import IndustryCard from '../components/IndustryCard';
import Filters from '../components/Filters';

// This is the main page that shows all industries
export default function Home() {
  // This hook fetches all industries from the API
  // It gives us: data (industries), isLoading (true/false), error (if any)
  const { data: industries, isLoading, error } = useGetIndustriesQuery();
  
  // These are state variables to store user input
  const [searchTerm, setSearchTerm] = useState('');      // What user types in search bar
  const [filterText, setFilterText] = useState('');      // What user types in filter box
  const [sortBy, setSortBy] = useState('name-asc');      // How to sort (A-Z, Z-A, etc.)

  // This function filters and sorts the industries based on user input
  // It runs every time searchTerm, filterText, sortBy, or industries change
  const filteredAndSortedIndustries = useMemo(() => {
    if (!industries) return [];  // If no data yet, return empty array

    // Step 1: Filter industries based on search and filter text
    let filtered = industries.filter((industry) => {
      const searchLower = searchTerm.toLowerCase();
      const filterLower = filterText.toLowerCase();
      
      // Check if industry matches search (looks in name, roles, behaviors)
      const matchesSearch = 
        industry.Industry.toLowerCase().includes(searchLower) ||
        (industry["Example Roles"] && industry["Example Roles"].toLowerCase().includes(searchLower)) ||
        (industry["Common Observable Behaviors"] && industry["Common Observable Behaviors"].toLowerCase().includes(searchLower));
      
      // Check if industry matches filter (looks in name and description)
      const matchesFilter = 
        industry.Industry.toLowerCase().includes(filterLower) ||
        industry.Description.toLowerCase().includes(filterLower);

      // Only show industries that match BOTH search and filter
      return matchesSearch && matchesFilter;
    });

    // Step 2: Sort the filtered results
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name-asc':      // A to Z by name
          return a.Industry.localeCompare(b.Industry);
        case 'name-desc':     // Z to A by name
          return b.Industry.localeCompare(a.Industry);
        case 'description-asc':   // A to Z by description
          return a.Description.localeCompare(b.Description);
        case 'description-desc':  // Z to A by description
          return b.Description.localeCompare(a.Description);
        default:
          return 0;
      }
    });

    return filtered;
  }, [industries, searchTerm, filterText, sortBy]);

  // If there's an error loading data, show error message
  if (error) {
    return (
      <Box>
        <Header onSearch={setSearchTerm} />
        <Container sx={{ mt: 4 }}>
          <Alert severity="error">
            Failed to load industries. Please try again later.
          </Alert>
        </Container>
      </Box>
    );
  }

  // Main page content
  return (
    <Box>
      {/* Header with search bar */}
      <Header onSearch={setSearchTerm} />
      
      <Container sx={{ mt: 4 }}>
        {/* Page title */}
        <Typography variant="h4" component="h1" gutterBottom>
          Industries
        </Typography>

        {/* Filter and sort controls */}
        <Filters
          sortBy={sortBy}
          onSortChange={setSortBy}
          filterText={filterText}
          onFilterChange={setFilterText}
        />

        {/* Show different content based on loading state */}
        {isLoading ? (
          // Show loading skeletons while data is loading
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 3 }}>
            {[...Array(6)].map((_, index) => (
              <Skeleton key={index} variant="rectangular" height={300} />
            ))}
          </Box>
        ) : filteredAndSortedIndustries.length === 0 ? (
          // Show message if no industries found
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Typography variant="h6" color="text.secondary">
              No industries found matching your criteria.
            </Typography>
          </Box>
        ) : (
          // Show the actual industry cards in a responsive grid
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 3 }}>
            {filteredAndSortedIndustries.map((industry) => (
              <IndustryCard key={industry.Industry} industry={industry} />
            ))}
          </Box>
        )}
      </Container>
    </Box>
  );
} 