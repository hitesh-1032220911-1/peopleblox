import React from 'react';
import { useRouter } from 'next/router';
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  CardMedia,
  Chip,
  List,
  ListItem,
  ListItemText,
  Button,
  Skeleton,
  Alert,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useGetIndustryByIdQuery } from '../../store/api/industriesApi';

// This is the detail page that shows full information about one industry
// The [id] in the filename means it's a dynamic route - the ID comes from the URL
export default function IndustryDetail() {
  const router = useRouter();  // Used to get data from the URL and navigate
  const { id } = router.query;  // Gets the industry name from the URL
  
  // Fetch all industries (we'll find the specific one client-side)
  const { data: industries, isLoading, error } = useGetIndustryByIdQuery(
    id as string,
    { skip: !id }  // Don't fetch if we don't have an ID yet
  );

  // Find the specific industry from the array using the ID from the URL
  const industry = industries?.find(ind => ind.Industry === decodeURIComponent(id as string));

  // Go back to the main page when user clicks the back button
  const handleBack = () => {
    router.push('/');
  };

  // Show error message if something went wrong
  if (error) {
    return (
      <Container sx={{ mt: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
          sx={{ mb: 2 }}
        >
          Back to Industries
        </Button>
        <Alert severity="error">
          Failed to load industry details. Please try again later.
        </Alert>
      </Container>
    );
  }

  // Show loading skeletons while data is loading
  if (isLoading) {
    return (
      <Container sx={{ mt: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
          sx={{ mb: 2 }}
        >
          Back to Industries
        </Button>
        <Box>
          <Skeleton variant="rectangular" height={300} sx={{ mb: 2 }} />
          <Skeleton variant="text" height={60} sx={{ mb: 1 }} />
          <Skeleton variant="text" height={40} sx={{ mb: 2 }} />
          <Skeleton variant="text" height={20} sx={{ mb: 1 }} />
          <Skeleton variant="text" height={20} sx={{ mb: 1 }} />
          <Skeleton variant="text" height={20} sx={{ mb: 2 }} />
        </Box>
      </Container>
    );
  }

  // Show message if industry not found
  if (!industry) {
    return (
      <Container sx={{ mt: 4 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
          sx={{ mb: 2 }}
        >
          Back to Industries
        </Button>
        <Typography variant="h6" color="text.secondary">
          Industry not found.
        </Typography>
      </Container>
    );
  }

  // Show the full industry details
  return (
    <Container sx={{ mt: 4 }}>
      {/* Back button to return to main page */}
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={handleBack}
        sx={{ mb: 2 }}
      >
        Back to Industries
      </Button>

      {/* Main industry card with all details */}
      <Card>
        {/* Large industry image */}
        <CardMedia
          component="img"
          height="300"
          image={industry.ImageUrl || '/placeholder.jpg'}
          alt={industry.Industry}
          sx={{ objectFit: 'cover' }}
        />
        
        {/* Industry information */}
        <CardContent>
          {/* Industry name as main heading */}
          <Typography variant="h4" component="h1" gutterBottom>
            {industry.Industry}
          </Typography>
          
          {/* Industry description */}
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            {industry.Description}
          </Typography>

          {/* Show behaviors if they exist */}
          {industry["Common Observable Behaviors"] && (
            <Box sx={{ mb: 3 }}>
              <Typography variant="h6" gutterBottom>
                Common Observable Behaviors
              </Typography>
              <List dense>
                {/* Split behaviors by comma and show each one */}
                {industry["Common Observable Behaviors"].split(', ').map((behavior: string, index: number) => (
                  <ListItem key={index} sx={{ py: 0.5 }}>
                    <ListItemText primary={behavior} />
                  </ListItem>
                ))}
              </List>
            </Box>
          )}

          {/* Show companies if they exist */}
          {industry["Example Companies"] && (
            <Box sx={{ mb: 3 }}>
              <Typography variant="h6" gutterBottom>
                Example Companies
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {/* Split companies by comma and show each one as a chip */}
                {industry["Example Companies"].split(', ').map((company: string, index: number) => (
                  <Chip key={index} label={company} color="primary" />
                ))}
              </Box>
            </Box>
          )}

          {/* Show roles if they exist */}
          {industry["Example Roles"] && (
            <Box>
              <Typography variant="h6" gutterBottom>
                Example Roles
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {/* Split roles by comma and show each one as an outlined chip */}
                {industry["Example Roles"].split(', ').map((role: string, index: number) => (
                  <Chip key={index} label={role} variant="outlined" />
                ))}
              </Box>
            </Box>
          )}
        </CardContent>
      </Card>
    </Container>
  );
} 