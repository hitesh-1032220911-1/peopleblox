import type { AppProps } from 'next/app';
import { Provider } from 'react-redux';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { store } from '../store/store';

// This creates our app's color theme
// Primary color is blue, secondary is pink
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',  // Blue color for buttons, links, etc.
    },
    secondary: {
      main: '#dc004e',  // Pink color for secondary elements
    },
  },
});

// This is the main app wrapper - it wraps every page in our app
// It provides Redux store and Material UI theme to all components
export default function App({ Component, pageProps }: AppProps) {
  return (
    <Provider store={store}>
      {/* Provider gives Redux store to all child components */}
      <ThemeProvider theme={theme}>
        {/* ThemeProvider gives Material UI theme to all child components */}
        <CssBaseline />
        {/* CssBaseline resets browser default styles for consistent look */}
        <Component {...pageProps} />
        {/* This renders the actual page content */}
      </ThemeProvider>
    </Provider>
  );
} 