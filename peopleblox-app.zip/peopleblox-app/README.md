# Peopleblox Industries App

A simple React + Next.js application that displays industry data from the Peopleblox Open API.

## Features

- Display industries in a responsive grid layout
- Search functionality with debouncing
- Filter and sort industries
- Individual industry detail pages
- Loading states and error handling
- Mobile responsive design

## Tech Stack

- React + Next.js
- TypeScript
- Material UI (MUI)
- Redux Toolkit (RTK) with RTK Query
- Emotion for styling

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

- `/src/pages` - Next.js pages
- `/src/components` - Reusable React components
- `/src/store` - Redux store and API slices
- `/src/utils` - Utility functions

## API

The app fetches data from the Peopleblox Open API:
- Industries list: `https://api.peopleblox.com/openapi/industries`
- Individual industry: `https://api.peopleblox.com/openapi/industries/{id}`
